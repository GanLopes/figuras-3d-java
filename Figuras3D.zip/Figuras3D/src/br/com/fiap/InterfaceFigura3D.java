package br.com.fiap;

public interface InterfaceFigura3D {

	public Double calcularVolume();
}
